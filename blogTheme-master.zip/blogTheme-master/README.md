###Jekyll 博客主题实践/About

随着 GitHub 的发展和 Jekyll 建站的方便，越来越多人使用 Jekyll 构件博客。blogTheme 是 <a href="http://www.pizn.me" target="_blank">PIZn</a> 的一个设计和开发的实践，在于提供更多的 Jekyll 主题，方便大家快速建立自己的博客。

###主题列表/Theme

* Violet Theme 1.0
* Black Cube Theme 1.0
* <a href="http://www.pizn.net/14-11-2012/theone-blog-theme/">theOne Theme 1.0</a>

###LICENSE

由 <a href="http://www.pizn.me" target="_blank">PIZn</a> 设计的这些主题列表，均是开源。只要您在使用的时候，注明由 <a href="http://www.pizn.me" target="_blank">PIZn</a> 设计和编写既可。代码均采用 <a href="http://zh.wikipedia.org/wiki/MIT_License" target="_blank">MIT LICENSE</a> 许可.

###联系作者/Contact

Email: pizner#gmail.com
