###主题介绍

* version :  1.0
* name    :  Black Cube Theme
* color   :  black
* create  :  2012-04-25
* author  :  PIZn
* support :  index, archives, contact

###Other

这是一款黑色主题，目前支持 3 个页面，分别是 index.html, archives.html,
contact.html。
