---
layout: post
title: Configuration
categories: [general, setup, demo]
tags: [demo, dbyll, dbtek, setup]
fullview: true
---

In your config file change these settings

{% highlight yaml %}
title: dbyll
author:  
  name: yourname  
  email: youremail  
  github: asd123  
  twitter: asd123  
  pinterest: asd123  
  linkedin: asd123  
  resume: asd123  
  bio: Your stylish,  minimalist theme!  
  email_md5: md5ofemail  
{% endhighlight %}